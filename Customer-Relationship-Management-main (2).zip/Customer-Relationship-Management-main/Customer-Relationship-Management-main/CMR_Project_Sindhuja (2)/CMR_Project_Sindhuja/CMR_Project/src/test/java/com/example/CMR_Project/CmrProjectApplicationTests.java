package com.example.CMR_Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmrProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
